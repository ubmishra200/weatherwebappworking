import './App.css';
import Ccard from './componets/Ccard';

function App() {
  return (
    <div className="App-header">
    <Ccard></Ccard>

    </div>
  );
}

export default App;
