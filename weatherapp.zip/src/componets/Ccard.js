import React, { useEffect, useState } from 'react'
import SearchIcon from '@mui/icons-material/Search';
import ThermostatIcon from '@mui/icons-material/Thermostat';

import '../App.css'
function Ccard() {
  const [search, setserch] = useState(null);
  const [city, setcity] = useState("gonda");
  useEffect(() => {
    const apikey = async () => {
      const api = `https://api.openweathermap.org/data/2.5/weather?q=${search}&units=metric&appid=6ecb395ff6ff3cc383f117d98db3205c`
      let mst = await fetch(api)
      const msts = await mst.json()
      setcity(msts.main);
    }
    apikey()
  }, [search])
  return (
    <div className='card'>
      <div>
        <h2>Weather App  </h2>
        <div>
          <label htmlFor="search">Search: <SearchIcon /></label>
          <input type="search"
            onChange={(even) => { setserch(even.target.value) }}
            className='inputbox'
            defaultValue="lucknow"
            placeholder='Enter city name'
            size={70}
          />

        </div>
        <div>
          {!city?(
            <p>data not found</p>
          ):(
            <>
            <h3 ><ThermostatIcon />{search}</h3>
          <h3>{city.temp}°C</h3>
          <p>minTemp:{city.temp_min} °C | maxTemp:{city.temp_max} °C</p>
            </>
          )}
        </div>
      </div>

    </div>
  )
}

export default Ccard